const DICT=`Acceleration|Rate of change of velocity (m/s²)
Amplitude|Maximum displacement from equilibrium
Angular velocity|Rate of change of angular position (rad/s)
Atomic number|Number of protons in a nucleus
Buoyancy|Upward force a fluid exerts on a submerged object
Capacitance|Charge stored per unit voltage (farad)
Centripetal force|Net inward force that keeps an object moving in a circle
Conduction|Heat transfer through direct particle contact
Convection|Heat transfer by bulk movement of a fluid
Coulomb|SI unit of electric charge
Density|Mass per unit volume
Diffraction|Spreading of waves around obstacles or through gaps
Displacement|Straight-line change in position, with direction
Doppler effect|Frequency change due to relative motion of source and observer
Efficiency|Useful output divided by total input
Electric field|Force per unit charge at a point
EMF|Energy supplied per unit charge by a source (volts)
Entropy|Measure of disorder; always increases in isolated systems
Equilibrium|State where net force and net torque are zero
Frequency|Number of cycles per second (hertz)
Friction|Force opposing relative motion of surfaces
Half-life|Time for half of radioactive nuclei to decay
Impulse|Force multiplied by time; equals change in momentum
Inertia|Resistance of an object to changes in motion
Interference|Superposition of waves producing reinforcement or cancellation
Isotope|Atoms of the same element with different neutron numbers
Joule|SI unit of energy and work
Kinetic energy|Energy due to motion
Latent heat|Energy absorbed or released during a phase change
Magnetic flux|Magnetic field passing through an area (weber)
Momentum|Mass times velocity
Newton|SI unit of force
Ohm|SI unit of electrical resistance
Photon|Quantum packet of electromagnetic energy
Potential difference|Energy transferred per unit charge between two points
Power|Rate of doing work (watt)
Pressure|Force per unit area (pascal)
Reflection|Waves bouncing off a boundary
Refraction|Bending of waves as they change speed in a new medium
Resistance|Opposition to electric current
Resonance|Large oscillation when driven at the natural frequency
Specific heat capacity|Energy needed to raise 1 kg by 1 K
Speed|Distance travelled per unit time
Temperature|Measure of average kinetic energy of particles
Terminal velocity|Constant speed when drag equals driving force
Torque|Turning effect of a force
Velocity|Rate of change of displacement, with direction
Wavelength|Distance between successive wave crests
Work|Energy transferred by a force acting over a distance`.split('\n').map(l=>l.split('|'));
const SYM=`a|acceleration|m/s²
A|area|m²
B|magnetic field|T
c|speed of light / specific heat|m/s, J/kg·K
E|energy / electric field|J, N/C
f|frequency|Hz
F|force|N
g|gravitational acceleration|m/s²
h|height / Planck constant|m, J·s
I|current / intensity / inertia|A, W/m², kg·m²
k|spring constant|N/m
L|length / inductance|m, H
m|mass|kg
n|refractive index / moles|–, mol
p|momentum|kg·m/s
P|power / pressure|W, Pa
q|charge|C
Q|heat|J
r|radius|m
R|resistance|Ω
T|period / temperature|s, K
t|time|s
U|potential energy|J
v|velocity|m/s
V|voltage / volume|V, m³
W|work|J
λ|wavelength|m
μ|friction coefficient|–
ρ|density / resistivity|kg/m³, Ω·m
τ|torque / time constant|N·m, s
ω|angular velocity|rad/s
Φ|magnetic flux|Wb`.split('\n').map(l=>l.split('|'));
const PHYS=`Isaac Newton|1643–1727|Laws of motion and universal gravitation
Galileo Galilei|1564–1642|Founded experimental kinematics; telescope astronomy
Michael Faraday|1791–1867|Electromagnetic induction and field concepts
James Clerk Maxwell|1831–1879|Unified electricity, magnetism and light
Marie Curie|1867–1934|Radioactivity; two Nobel Prizes
Albert Einstein|1879–1955|Relativity and the photoelectric effect
Niels Bohr|1885–1962|Quantised model of the atom
Max Planck|1858–1947|Originated quantum theory
Erwin Schrödinger|1887–1961|Wave equation of quantum mechanics
Stephen Hawking|1942–2018|Black-hole radiation and cosmology
Lise Meitner|1878–1968|Explained nuclear fission
Chien-Shiung Wu|1912–1997|Disproved parity conservation`.split('\n').map(l=>l.split('|'));
// [question, options, correct index, topic]
const QUIZ=[["A car accelerates from rest at 2 m/s² for 5 s. Final speed?",["5 m/s","10 m/s","20 m/s","25 m/s"],1,"Kinematics"],
["Which quantity is a vector?",["Speed","Energy","Displacement","Mass"],2,"Kinematics"],
["Net force 10 N on 2 kg gives acceleration:",["5 m/s²","20 m/s²","0.2 m/s²","12 m/s²"],0,"Newton's Laws & Friction"],
["Work done by a 20 N force over 3 m in its direction:",["6.7 J","23 J","60 J","17 J"],2,"Work, Energy & Power"],
["Kinetic energy of 2 kg at 3 m/s:",["3 J","6 J","9 J","18 J"],2,"Work, Energy & Power"],
["Momentum is conserved when:",["Net external force is zero","Energy is lost","Mass is constant","Speed is constant"],0,"Momentum & Collisions"],
["Centripetal force points:",["Outward","Tangent","Toward the centre","Along velocity"],2,"Circular Motion"],
["Escape velocity depends on:",["Mass of the escaping object","Mass and radius of the planet","Launch angle","Atmosphere only"],1,"Gravitation"],
["Period of a simple pendulum depends on:",["Mass","Amplitude","Length and g","Material"],2,"Simple Harmonic Motion"],
["Pressure at depth h in fluid of density ρ:",["ρgh","ρh/g","gh/ρ","ρg/h"],0,"Fluids"],
["Heat needed to warm 2 kg by 5 K, c = 400 J/kg·K:",["800 J","2000 J","4000 J","200 J"],2,"Heat & Temperature"],
["The 2nd law of thermodynamics concerns:",["Entropy","Charge","Momentum","Refraction"],0,"Gas Laws & Laws of Thermodynamics"],
["Wave speed with f = 50 Hz, λ = 2 m:",["25 m/s","52 m/s","100 m/s","0.04 m/s"],2,"Waves"],
["A source moving toward you makes observed frequency:",["Lower","Higher","Unchanged","Zero"],1,"Sound & Doppler Effect"],
["Light entering a denser medium:",["Speeds up","Slows down","Stays same","Stops"],1,"Reflection, Refraction & Lenses"],
["Resistors 4 Ω and 4 Ω in parallel give:",["8 Ω","4 Ω","2 Ω","16 Ω"],2,"Current Electricity"],
["Power with 12 V and 2 A:",["6 W","14 W","24 W","10 W"],2,"Current Electricity"],
["Force between charges depends on distance as:",["1/r","1/r²","r","r²"],1,"Electrostatics"],
["Changing magnetic flux induces:",["Mass","EMF","Heat only","Gravity"],1,"Magnetism & Induction"],
["Transformer with Np = 100, Ns = 200, Vp = 10 V gives Vs:",["5 V","20 V","200 V","10 V"],1,"Inductance, Transients & Transformers"],
["Rest energy of mass m:",["mc","mc²","m²c","½mc²"],1,"Special Relativity"],
["Photon energy is proportional to:",["Frequency","Amplitude","Wavelength","Intensity"],0,"Quantum Physics"],
["After 3 half-lives, fraction remaining:",["1/3","1/6","1/8","1/9"],2,"Atomic & Nuclear Physics"],
["Total internal reflection needs light going from:",["Dense to less dense","Less dense to dense","Air to air","Any"],0,"Wave Optics & Optical Instruments"],
["Hotter stars peak at:",["Longer wavelengths","Shorter wavelengths","Same wavelength","No peak"],1,"Stars & Cosmology"]];
const DERIV={"Final velocity":"From a = dv/dt with constant a: ∫dv = a∫dt, so v − u = at.","Displacement":"Integrate v = u + at over time: s = ∫(u + at)dt = ut + ½at².","Velocity from distance":"Eliminate t between v = u + at and s = ut + ½at² to get v² = u² + 2as.","Kinetic energy":"W = ∫F ds = ∫m(dv/dt)v dt = ∫mv dv = ½mv².","Escape velocity":"Set ½mv² = GMm/r (kinetic energy equals the gravitational binding energy).","Centripetal acceleration":"Velocity vector turns through Δθ = vΔt/r, so Δv = vΔθ and a = v²/r.","Pendulum period":"For small θ, torque gives θ'' = −(g/L)θ; this is SHM with ω = √(g/L), so T = 2π√(L/g).","Ohm's law":"Experimentally, V ∝ I for ohmic conductors; R = V/I is the constant of proportionality.","Rest energy":"From E² = (pc)² + (mc²)², setting p = 0 gives E = mc².","Photon energy":"Planck's quantum hypothesis: energy comes in packets proportional to frequency, E = hf.","Projectile range":"Time of flight 2u sinθ/g times horizontal speed u cosθ gives R = u² sin2θ/g."};
const ADV=["Elasticity & Materials","Fluid Dynamics & Viscosity","Interference & Standing Waves","Wave Optics & Optical Instruments","Gauss's Law & Electric Potential","Inductance, Transients & Transformers","Electromagnetic Waves","Atomic Models & X-rays","Nuclear Energy & Particle Physics","Semiconductors & Electronics","Orbits & Gravitational Fields","Stars & Cosmology","Rotational Motion","Special Relativity","Quantum Physics","Atomic & Nuclear Physics"];
