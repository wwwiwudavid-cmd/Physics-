const LS={get(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let LEVEL=LS.get('level','all');
const list=(a,fn)=>a.map(fn).join('');
const VIEWS={
 dict(v){v.innerHTML=`<div class="cat">Reference</div><h2>Dictionary</h2><input id="dq" placeholder="Filter ${DICT.length} terms…"><div id="dl"></div>`;const r=q=>$('#dl').innerHTML=list(DICT.filter(d=>(d[0]+d[1]).toLowerCase().includes(q)),d=>`<div class="hit"><b>${d[0]}</b><p>${d[1]}</p></div>`);$('#dq').oninput=e=>r(e.target.value.toLowerCase());r('')},
 sym(v){v.innerHTML=`<div class="cat">Reference</div><h2>Symbols & units</h2>`+list(SYM,s=>`<div class="hit"><b style="font:700 20px Georgia,serif">${s[0]}</b> ${s[1]}<p>${s[2]}</p></div>`)},
 phys(v){v.innerHTML=`<div class="cat">History</div><h2>Physicists</h2>`+list(PHYS,p=>`<div class="hit"><b>${p[0]}</b> <span style="color:var(--mute)">${p[1]}</span><p>${p[2]}</p></div>`)},
 saved(v){const b=LS.get('bm',[]);v.innerHTML=`<div class="cat">Your library</div><h2>Saved formulas</h2>`+(b.length?list(b,n=>{const t=TOPICS.find(t=>t[3].some(f=>f[0]==n));return t?`<div class="hit"><a href="#${slug(t[1])}">${n}</a><p>${t[1]}</p></div>`:''}):'<p class="lead">Tap ☆ on any formula to save it here.</p>')},
 quiz(v){let q=[],i=0,s=0;const pool=QUIZ;
  v.innerHTML=`<div class="cat">Practice</div><h2>Quiz</h2><div class="f"><div class="row"><div><label>Topic</label><select id="qt"><option value="">All topics</option>${list([...new Set(QUIZ.map(x=>x[3]))],t=>`<option>${t}</option>`)}</select></div><button class="p" id="qs">Start quiz</button></div></div><div id="qb"></div>`;
  const show=()=>{const b=$('#qb');if(i>=q.length){b.innerHTML=`<div class="f"><h3>Score: ${s}/${q.length}</h3><p>${s==q.length?'Perfect.':'Review the topics you missed and try again.'}</p></div>`;return}
   const x=q[i];b.innerHTML=`<div class="f"><label>Question ${i+1} of ${q.length} · ${x[3]}</label><h3>${x[0]}</h3>${list(x[1],(o,k)=>`<p><button data-k="${k}" style="width:100%;text-align:left">${o}</button></p>`)}<div class="res" id="qr"></div></div>`;
   b.querySelectorAll('button').forEach(bt=>bt.onclick=()=>{const ok=+bt.dataset.k==x[2];if(ok)s++;b.querySelectorAll('button').forEach((z,k)=>{z.disabled=true;if(k==x[2])z.style.borderColor='var(--acc)'});$('#qr').innerHTML=(ok?'Correct. ':'Not quite. ')+`<button class="p" id="nx">Next</button>`;$('#nx').onclick=()=>{i++;show()}})};
  $('#qs').onclick=()=>{const t=$('#qt').value;q=pool.filter(x=>!t||x[3]==t).sort(()=>Math.random()-.5);i=s=0;if(q.length)show();else $('#qb').textContent='No questions for this topic yet.'}}
};
function post(h){
 const bm=LS.get('bm',[]),notes=LS.get('notes',{});
 document.querySelectorAll('.f[data-o]').forEach(box=>{const n=box.querySelector('h3').textContent,h3=box.querySelector('h3');
  const st=document.createElement('button');st.textContent=bm.includes(n)?'★':'☆';st.title='Save formula';st.setAttribute('aria-label','Save '+n);st.style.cssText='float:right;padding:2px 10px';
  st.onclick=()=>{let b=LS.get('bm',[]);b=b.includes(n)?b.filter(x=>x!=n):[...b,n];LS.set('bm',b);st.textContent=b.includes(n)?'★':'☆'};h3.before(st);
  const d=DERIV[n];box.insertAdjacentHTML('beforeend',(d?`<details><summary>Derivation</summary><p>${d}</p></details>`:'')+`<details><summary>My notes</summary><textarea rows="2" style="width:100%;font:inherit;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:10px;padding:8px" placeholder="Add a note…">${(notes[n]||'').replace(/</g,'&lt;')}</textarea></details>`);
  box.querySelector('textarea').oninput=e=>{const o=LS.get('notes',{});o[n]=e.target.value;LS.set('notes',o)}});
 nav.querySelectorAll('a').forEach(a=>{const t=TOPICS.find(t=>slug(t[1])==a.hash.slice(1));if(t)a.style.display=LEVEL=='all'||(LEVEL=='adv')==ADV.includes(t[1])?'':'none'});
 if(!$('#lv')){$('.bar').insertAdjacentHTML('afterend',`<select id="lv" aria-label="Level" style="margin-top:8px"><option value="all">All levels</option><option value="core">Core (GCSE · WAEC · AP 1 · Grade 9–12)</option><option value="adv">Advanced (A-Level · IB · AP 2/C · JEE · Univ)</option></select>`);$('#lv').value=LEVEL;$('#lv').onchange=e=>{LEVEL=e.target.value;LS.set('level',LEVEL);post()}}
 const q=$('#q');if(!q.dataset.h){q.dataset.h=1;q.addEventListener('keydown',e=>{if(e.key=='Enter'&&q.value.trim()){const r=[q.value.trim(),...LS.get('rec',[]).filter(x=>x!=q.value.trim())].slice(0,8);LS.set('rec',r)}});
  q.addEventListener('focus',()=>{const r=LS.get('rec',[]);if(!q.value&&r.length)view.innerHTML=`<h2>Recent searches</h2>`+list(r,x=>`<div class="hit"><a href="#" data-s="${x}">${x}</a></div>`)});
  view.addEventListener('click',e=>{if(e.target.dataset.s){e.preventDefault();q.value=e.target.dataset.s;q.dispatchEvent(new Event('input'))}})}
}
