Wise Physics (installable PWA, global syllabi: AP, IB, A-Level, GCSE, WAEC, JEE/NEET) - open index.html in any browser (works offline).
Add topics in data.js: [category, title, summary, [[name, display, output, "inputs", "expression"]]].
