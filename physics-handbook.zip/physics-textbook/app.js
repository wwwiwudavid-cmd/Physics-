const $=s=>document.querySelector(s),view=$('#view'),nav=$('#nav'),side=$('#side');
const slug=t=>t.toLowerCase().replace(/[^a-z0-9]+/g,'-');
const nf=n=>!isFinite(n)?'undefined':(Math.abs(n)>=1e5||(n!==0&&Math.abs(n)<1e-3))?n.toExponential(4):+n.toPrecision(6)+'';
const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let theme=localStorage.getItem('theme')||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');
const setT=()=>{document.documentElement.dataset.t=theme;try{localStorage.setItem('theme',theme)}catch(e){}};setT();
$('#th').onclick=()=>{theme=theme=='dark'?'light':'dark';setT()};$('#mb').onclick=()=>side.classList.toggle('open');
$('#count').textContent=TOPICS.length+' topics · '+TOPICS.reduce((a,t)=>a+t[3].length,0)+' formulas · '+TOPICS.reduce((a,t)=>a+t[3].length,0)+' calculators';
function buildNav(){let h='',c='',cur=location.hash.slice(1);
 h+='<h4>Tools</h4>'+[['calc','Scientific calculator'],['conv','Unit converter'],['const','Constants'],['quiz','Quiz'],['saved','Saved formulas'],['dict','Dictionary'],['sym','Symbols & units'],['phys','Physicists']].map(x=>`<a href="#${x[0]}" class="${cur==x[0]?'on':''}">${x[1]}</a>`).join('');
 TOPICS.forEach(t=>{if(t[0]!=c){c=t[0];h+=`<h4>${c}</h4>`}h+=`<a href="#${slug(t[1])}" class="${cur==slug(t[1])?'on':''}">${t[1]}</a>`});nav.innerHTML=h}
function topic(t){return`<div class="cat">${t[0]}</div><h2>${t[1]}</h2><p class="lead">${t[2]}</p>`+t[3].map((f,i)=>{
 const vs=f[3].split(',');return`<div class="f" data-o="${f[4]}" data-v="${f[3]}"><h3>${f[0]}</h3><div class="eq">${esc(f[1])}</div>
 <div class="row">${vs.map(v=>`<div><label>${v}</label><input inputmode="decimal" data-k="${v}" placeholder="${v}"></div>`).join('')}<button class="p">Solve for ${f[2]}</button></div><div class="res" aria-live="polite"></div></div>`}).join('')}
function solve(box){const vs=box.dataset.v.split(','),vals=[];
 for(const v of vs){const x=parseFloat(box.querySelector(`[data-k="${v}"]`).value);if(isNaN(x)){box.querySelector('.res').textContent='Enter a value for '+v;return}vals.push(x)}
 try{box.querySelector('.res').textContent='= '+nf(new Function(...vs,'C','return '+box.dataset.o)(...vals,C))}catch(e){box.querySelector('.res').textContent='Could not calculate'}}
view.addEventListener('click',e=>{if(e.target.matches('.f button'))solve(e.target.closest('.f'))});
view.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.matches('.f input'))solve(e.target.closest('.f'))});
function calc(){const keys='C ( ) ÷ 7 8 9 × 4 5 6 − 1 2 3 + 0 . ^ = sin cos tan √ ln log π e ⌫'.split(' ');
 view.innerHTML=`<div class="cat">Tools</div><h2>Scientific calculator</h2><p class="lead">Trig functions use degrees. Tap = to evaluate.</p><div class="calc"><div class="disp" id="d">0</div>${keys.map(k=>`<button data-k="${k}">${k}</button>`).join('')}</div>`;
 let ex='';const d=$('#d'),show=()=>d.textContent=ex||'0';
 view.querySelector('.calc').onclick=e=>{const k=e.target.dataset.k;if(!k)return;
  if(k=='C')ex='';else if(k=='⌫')ex=ex.replace(/(sin\(|cos\(|tan\(|√\(|ln\(|log\(|.)$/,'');
  else if(k=='='){try{let s=ex.replace(/÷/g,'/').replace(/×/g,'*').replace(/−/g,'-').replace(/\^/g,'**').replace(/π/g,'Math.PI').replace(/(?<![a-z])e(?![a-z])/g,'Math.E').replace(/sin\(/g,'S(').replace(/cos\(/g,'Co(').replace(/tan\(/g,'T(').replace(/√\(/g,'Math.sqrt(').replace(/ln\(/g,'Math.log(').replace(/log\(/g,'Math.log10(');
   if(!/^[0-9+\-*/().,\sA-Za-z]*$/.test(s))throw 0;const r=new Function('S','Co','T',`return ${s}`)(x=>Math.sin(x*Math.PI/180),x=>Math.cos(x*Math.PI/180),x=>Math.tan(x*Math.PI/180));ex=nf(r)}catch(_){ex='';d.textContent='Check expression';return}}
  else ex+=['sin','cos','tan','√','ln','log'].includes(k)?k+'(':k;show()}}
function search0(q){q=q.toLowerCase().trim();const hits=TOPICS.filter(t=>(t[0]+t[1]+t[2]+t[3].map(f=>f[0]+f[1]).join(' ')).toLowerCase().includes(q));
 view.innerHTML=`<h2>${hits.length} result${hits.length==1?'':'s'}</h2>`+(hits.map(t=>`<div class="hit"><a href="#${slug(t[1])}">${t[1]}</a><p>${t[0]} · ${t[3].map(f=>f[0]).join(', ')}</p></div>`).join('')||'<p class="lead">No match. Try a formula name like “power” or a topic like “optics”.</p>')}
function home(){view.innerHTML=`<div class="cat">Complete reference</div><h2>Wise Physics</h2><p class="lead">Mechanics to quantum physics: concise theory, every key formula, and a solver on each one. Pick a topic or search.</p>`+TOPICS.map(t=>`<div class="hit"><a href="#${slug(t[1])}">${t[1]}</a><p>${t[0]} · ${t[3].length} formulas</p></div>`).join('')}
function route(){const h=location.hash.slice(1);buildNav();side.classList.remove('open');$('#q').value='';
 if(h=='calc')calc();else if(VIEWS[h])VIEWS[h](view);else if(h=='conv')convView(view);else if(h=='const')constView(view);else{const t=TOPICS.find(t=>slug(t[1])==h);t?view.innerHTML=topic(t):home()}post(h);main_scroll()}
const main_scroll=()=>document.querySelector('main').scrollTo(0,0);
$('#q').oninput=e=>e.target.value.trim()?search(e.target.value):route();
addEventListener('hashchange',route);route();
