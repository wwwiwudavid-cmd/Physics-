const ADD2={"Kinematics":[["Average speed","v = d/t","v","d,t","d/t"],["Time of flight","T = 2u sinθ/g","T","u,theta","2*u*Math.sin(theta*Math.PI/180)/C.g"],["Free-fall time","t = √(2h/g)","t","h","Math.sqrt(2*h/C.g)"],["Stopping distance","s = u²/2a","s","u,a","u*u/(2*a)"]],
"Newton's Laws & Friction":[["Normal force on incline","N = mg cosθ","N","m,theta","m*C.g*Math.cos(theta*Math.PI/180)"],["Lift cable tension","T = m(g + a)","T","m,a","m*(C.g+a)"],["Atwood machine acceleration","a = (m₁−m₂)g/(m₁+m₂)","a","m1,m2","(m1-m2)*C.g/(m1+m2)"]],
"Work, Energy & Power":[["Power from force and speed","P = Fv","P","F,v","F*v"],["Work-energy theorem","W = ½m(v²−u²)","W","m,v,u","0.5*m*(v*v-u*u)"]],
"Momentum & Collisions":[["Recoil speed","v = m₁u₁/m₂","v","m1,u1,m2","m1*u1/m2"],["Average force from momentum","F = m(v−u)/t","F","m,v,u,t","m*(v-u)/t"]],
"Circular Motion":[["Banked curve speed","v = √(rg tanθ)","v","r,theta","Math.sqrt(r*C.g*Math.tan(theta*Math.PI/180))"],["Linear speed","v = ωr","v","w,r","w*r"]],
"Gravitation":[["Surface gravity","g = GM/R²","g","M,R","C.G*M/(R*R)"]],
"Rotational Motion":[["Angular acceleration","α = τ/I","alpha","tau,I","tau/I"],["Rolling sphere speed (from rest)","v = √(10gh/7)","v","h","Math.sqrt(10*C.g*h/7)"]],
"Simple Harmonic Motion":[["Maximum SHM speed","vmax = Aω","v","A,w","A*w"],["Total SHM energy","E = ½kA²","E","k,A","0.5*k*A*A"]],
"Fluids":[["Torricelli speed","v = √(2gh)","v","h","Math.sqrt(2*C.g*h)"],["Density","ρ = m/V","rho","m,V","m/V"]],
"Heat & Temperature":[["Fahrenheit → Celsius","°C = (°F−32)×5/9","C","Tf","(Tf-32)*5/9"]],
"Gas Laws & Laws of Thermodynamics":[["Boyle's law (P₂)","P₁V₁ = P₂V₂","P2","P1,V1,V2","P1*V1/V2"],["Charles's law (V₂)","V₁/T₁ = V₂/T₂","V2","V1,T1,T2","V1*T2/T1"],["Isobaric work","W = PΔV","W","P,dV","P*dV"]],
"Waves":[["Wave number","k = 2π/λ","k","lambda","2*Math.PI/lambda"]],
"Sound & Doppler Effect":[["Open pipe fundamental","f = v/2L","f","v,L","v/(2*L)"]],
"Reflection, Refraction & Lenses":[["Refractive index from speed","n = c/v","n","v","C.c/v"]],
"Electrostatics":[["Capacitors in parallel","C = C₁ + C₂","Cap","C1,C2","C1+C2"]],
"Current Electricity":[["Electrical energy","E = Pt","E","P,t","P*t"],["Terminal voltage","V = ε − Ir","V","emf,I,r","emf-I*r"]],
"Magnetism & Induction":[["Force on current wire","F = BIL","F","B,I,L","B*I*L"],["Magnetic flux","Φ = BA cosθ","Phi","B,A,theta","B*A*Math.cos(theta*Math.PI/180)"],["Solenoid field","B = μ₀nI","B","n,I","C.mu0*n*I"],["Motional EMF","ε = BLv","emf","B,L,v","B*L*v"]],
"Special Relativity":[["Relativistic momentum","p = γmv","p","m,v","m*v/Math.sqrt(1-v*v/(C.c*C.c))"],["Length contraction","L = L₀√(1−v²/c²)","L","L0,v","L0*Math.sqrt(1-v*v/(C.c*C.c))"]],
"Quantum Physics":[["Photon momentum","p = h/λ","p","lambda","C.h/lambda"]]};
Object.entries(ADD2).forEach(([k,v])=>TOPICS.find(t=>t[1]==k)[3].push(...v));
{const have=new Set(DICT.map(d=>d[0].toLowerCase()));DICT.push(...`Absolute zero|Lowest possible temperature, 0 K
Absorption spectrum|Dark lines where a medium absorbs light
Accuracy|Closeness of a measurement to the true value
Adhesion|Attraction between unlike molecules
Air resistance|Drag force from air on moving objects
Alpha particle|Helium nucleus emitted in decay
Alternating current|Current that periodically reverses direction
Ammeter|Instrument measuring current
Ampere|SI unit of current
Angle of incidence|Angle between incoming ray and normal
Angle of reflection|Angle between reflected ray and normal
Angular displacement|Change in angle of rotation
Angular frequency|Rate of phase change, 2πf
Anode|Positive electrode
Antinode|Point of maximum amplitude in a standing wave
Archimedes' principle|Buoyant force equals weight of displaced fluid
Atmospheric pressure|Pressure from the weight of air
Atom|Smallest unit of an element
Average speed|Total distance divided by total time
Avogadro's number|6.022×10²³ particles per mole
Balanced forces|Forces whose resultant is zero
Barometer|Instrument measuring air pressure
Battery|Source of EMF from chemical energy
Beat|Periodic loudness variation from close frequencies
Beta particle|Electron or positron from nuclear decay
Big Bang|Origin and expansion of the universe
Binding energy|Energy needed to separate a nucleus
Boiling point|Temperature where liquid becomes vapour
Boyle's law|At constant T, pressure varies inversely with volume
Brownian motion|Random motion of particles in a fluid
Calorie|Energy to warm 1 g of water by 1 °C
Capillarity|Liquid rising in narrow tubes
Carnot cycle|Ideal reversible heat engine cycle
Cathode|Negative electrode
Cathode ray|Stream of electrons in a vacuum tube
Celsius|Temperature scale with water freezing at 0
Centre of gravity|Point where weight acts
Centrifugal force|Apparent outward force in a rotating frame
Chain reaction|Self-sustaining series of nuclear fissions
Charge|Property causing electric force
Charles's law|At constant P, volume varies with temperature
Circuit|Closed path for current
Cohesion|Attraction between like molecules
Collision|Interaction where bodies exert forces briefly
Component of a vector|Projection along an axis
Compression|Region of high pressure in a longitudinal wave
Conductor|Material allowing charge to flow
Conservation of energy|Total energy stays constant
Conservation of momentum|Total momentum of a closed system stays constant
Constructive interference|Waves adding to a larger amplitude
Control rod|Absorbs neutrons in a reactor
Coplanar forces|Forces in a single plane
Cosmic microwave background|Relic radiation of the early universe
Couple|Pair of equal opposite forces giving a torque
Current density|Current per unit area
Cyclotron|Particle accelerator using a magnetic field
Dark matter|Unseen mass inferred from gravity
Decay constant|Probability of decay per unit time
Deceleration|Acceleration that reduces speed
Decibel|Logarithmic unit of sound level
Derived unit|Unit built from base units
Destructive interference|Waves cancelling each other
Dispersion|Splitting of light by wavelength
Dynamics|Study of motion and its causes
Eddy current|Circulating current induced in a conductor
Elastic limit|Maximum stress before permanent deformation
Elasticity|Ability to regain shape after deformation
Electric current|Flow of charge
Electric flux|Field passing through a surface
Electrolysis|Chemical change driven by current
Electromagnet|Magnet powered by electric current
Electromagnetic induction|EMF produced by changing flux
Electromotive force|Energy per charge from a source
Electron|Negative subatomic particle
Electroscope|Device detecting charge
Electrostatics|Study of charges at rest
Emission spectrum|Light emitted by excited atoms
Energy level|Allowed energy state of an electron
Equipotential|Surface of constant potential
Error|Difference between measured and true value
Evaporation|Surface vaporisation below boiling
Excited state|Atom with electrons in higher levels
Fahrenheit|Temperature scale with water freezing at 32
Farad|SI unit of capacitance
Fermion|Particle with half-integer spin
Ferromagnetism|Strong magnetism of iron-like materials
Fibre optics|Light guided by total internal reflection
Field|Region where a force acts on matter
First law of thermodynamics|Energy is conserved including heat
Fluid|Substance that flows: liquid or gas
Flux density|Field strength per unit area
Focal length|Distance from lens to focus
Focus|Point where rays converge
Force|Push or pull that changes motion
Free fall|Motion under gravity alone
Freezing point|Temperature where liquid solidifies
Fundamental frequency|Lowest natural frequency of a system
Fuse|Safety device that melts on overload
Galvanometer|Sensitive instrument for small currents
Gas|State with no fixed shape or volume
Generator|Converts mechanical energy to electrical
Geostationary orbit|Orbit matching Earth's rotation
Gluon|Carrier of the strong force
Gradient|Slope of a graph
Graviton|Hypothetical carrier of gravity
Gravity|Attraction between masses
Ground state|Lowest energy state of an atom
Hadron|Particle made of quarks
Harmonic|Integer multiple of the fundamental frequency
Heat capacity|Energy needed to raise temperature by 1 K
Heat engine|Device converting heat to work
Henry|SI unit of inductance
Hertz|SI unit of frequency
Higgs boson|Particle linked to the Higgs field and mass
Hooke's law|Extension is proportional to force
Hubble's law|Galaxies recede at speed proportional to distance
Ideal gas|Gas with no molecular interactions
Image|Reproduction of an object by optics
Impedance|Total opposition to AC
Incident ray|Ray striking a surface
Inclined plane|Sloping surface
Induced current|Current produced by induction
Inelastic collision|Collision losing kinetic energy
Infrared|EM radiation just below red light
Instantaneous velocity|Velocity at a given moment
Insulator|Material resisting charge flow
Intensity|Power per unit area
Internal energy|Total kinetic and potential energy of particles
Internal resistance|Resistance inside a source
Ion|Atom with net charge
Ionisation|Removing electrons from an atom
Isobaric|At constant pressure
Isochoric|At constant volume
Isothermal|At constant temperature
Kelvin|SI unit of temperature
Kepler's laws|Three laws of planetary motion
Kilogram|SI unit of mass
Kinematics|Study of motion without forces
Kinetic theory|Gas properties explained by moving molecules
Kirchhoff's laws|Current and voltage rules for circuits
Laser|Source of coherent light
Law of reflection|Angle in equals angle out
Lens|Curved transparent device bending light
Lepton|Fundamental particle such as the electron
Lever|Rigid bar pivoting on a fulcrum
Light-year|Distance light travels in a year
Linear momentum|Product of mass and velocity
Liquid|State with fixed volume, no fixed shape
Load|Force or resistance a device must overcome
Longitudinal wave|Oscillation parallel to travel
Loudness|Perceived intensity of sound
Luminosity|Total power radiated by a star
Machine|Device that changes force or direction
Magnet|Object producing a magnetic field
Magnetic field|Region where magnetic force acts
Magnification|Image size divided by object size
Mass|Amount of matter; resistance to acceleration
Mass number|Protons plus neutrons
Mechanical advantage|Output force divided by input force
Melting point|Temperature where solid becomes liquid
Meson|Quark–antiquark particle
Metre|SI unit of length
Microscope|Instrument magnifying small objects
Mirror|Smooth surface reflecting light
Moderator|Slows neutrons in a reactor
Mole|Amount containing 6.022×10²³ particles
Moment|Turning effect of a force about a point
Monochromatic|Light of a single wavelength
Motor|Converts electrical energy to motion
Muon|Heavy lepton, a short-lived electron cousin
Natural frequency|Frequency a system oscillates at freely
Net force|Vector sum of all forces
Neutron|Neutral nuclear particle
Neutron star|Dense remnant of a collapsed star
Node|Point of zero amplitude in a standing wave
Normal|Line perpendicular to a surface
Nuclear force|Strong force binding nucleons
Nucleon|Proton or neutron
Nucleus|Dense central core of an atom
Optical fibre|Thin glass strand carrying light
Orbit|Curved path around a mass
Oscillation|Repeated back-and-forth motion
Parallel circuit|Components on separate branches
Pascal|SI unit of pressure
Pendulum|Mass swinging on a string
Period|Time for one cycle
Permeability|Ease of forming a magnetic field in a material
Phase|Position within a wave cycle
Photocell|Device converting light to current
Pitch|Perceived frequency of sound
Planck's constant|Ratio of photon energy to frequency
Plasma|Ionised gas
Polarity|Orientation of positive and negative poles
Positron|Antiparticle of the electron
Potentiometer|Variable voltage divider
Precision|Closeness of repeated measurements
Prism|Transparent block that disperses light
Proton|Positive nuclear particle
Pulley|Wheel that redirects a rope's force
Quantum|Smallest discrete unit of energy
Quark|Fundamental constituent of hadrons
Radian|Angle with arc length equal to radius
Radiation|Energy transfer by waves or particles
Radioactive decay|Nucleus emitting radiation
Rarefaction|Low-pressure region in a sound wave
Real image|Image formed by converging rays, projectable
Rectifier|Converts AC to DC
Reference frame|Viewpoint for measuring motion
Relativity|Theory linking space, time and motion
Resultant|Single vector equal to a vector sum
Rotation|Spinning about an axis
Scalar|Quantity with magnitude only
Second law of thermodynamics|Heat flows hot to cold; entropy increases
Series circuit|Components in one loop
Short circuit|Low-resistance path causing high current
Significant figures|Meaningful digits in a measurement
Simple harmonic motion|Oscillation with restoring force proportional to displacement
Snell's law|Relates angles of refraction to refractive indices
Solenoid|Coil that makes a magnetic field
Solid|State with fixed shape and volume
Specific gravity|Density relative to water
Spectrum|Distribution of wavelengths
Spin|Intrinsic angular momentum of a particle
Standing wave|Wave pattern with fixed nodes
Static equilibrium|Rest with zero net force and torque
Stress|Force per unit area inside a material
Strain|Fractional deformation
Surface tension|Force pulling liquid surfaces tight
Tension|Pulling force in a string
Thermodynamics|Study of heat, work and energy
Thermometer|Instrument measuring temperature
Threshold frequency|Minimum frequency to eject electrons
Time dilation|Moving clocks run slow
Total internal reflection|Complete reflection at a boundary
Trajectory|Path of a projectile
Transformer|Changes AC voltage by induction
Transistor|Semiconductor switch or amplifier
Turbulence|Chaotic fluid flow
Ultrasound|Sound above human hearing
Ultraviolet|EM radiation just above violet light
Unbalanced force|Nonzero net force
Uniform motion|Motion at constant velocity
Vacuum|Space with no matter
Vector|Quantity with magnitude and direction
Virtual image|Image formed by diverging rays, not projectable
Volt|SI unit of potential difference
Voltmeter|Instrument measuring voltage
Watt|SI unit of power
Wave|Disturbance carrying energy
Wave equation|v = fλ
Wavefront|Surface of constant phase
Weight|Gravitational force on a mass
White dwarf|Dense remnant of a sun-like star
Work function|Minimum energy to free an electron
X-ray|High-energy electromagnetic radiation
Young's modulus|Stress divided by strain
Zero-point energy|Lowest energy a quantum system can have`.split('\n').map(l=>l.split('|')).filter(d=>!have.has(d[0].toLowerCase())))}
