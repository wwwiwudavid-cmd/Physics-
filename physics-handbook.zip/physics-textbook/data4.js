QUIZ.push(
["A vector has components 3 and 4. Its magnitude is:",["5","7","12","1"],0,"Vectors & Measurement"],
["Which is a base SI unit?",["Newton","Kilogram","Joule","Watt"],1,"Vectors & Measurement"],
["Young's modulus is the ratio of:",["Stress to strain","Force to area","Strain to stress","Mass to volume"],0,"Elasticity & Materials"],
["Torque equals:",["Force × perpendicular distance","Mass × velocity","Force ÷ area","Work ÷ time"],0,"Rotational Motion"],
["Moment of inertia depends on:",["Mass distribution","Colour","Speed only","Temperature"],0,"Rotational Motion"],
["Bernoulli's principle: faster flow means:",["Lower pressure","Higher pressure","Same pressure","No flow"],0,"Fluid Dynamics & Viscosity"],
["Re above about 4000 usually indicates:",["Turbulent flow","Laminar flow","No flow","Static fluid"],0,"Fluid Dynamics & Viscosity"],
["Heating a metal rod makes it:",["Longer","Shorter","Lighter","Magnetic"],0,"Thermal Expansion & Kinetic Theory"],
["Average KE of gas molecules depends on:",["Temperature","Pressure only","Volume only","Gas colour"],0,"Thermal Expansion & Kinetic Theory"],
["Destructive interference occurs when waves are:",["In phase","Half a wavelength out of phase","Identical","Same amplitude only"],1,"Interference & Standing Waves"],
["Standing wave nodes are points of:",["Zero displacement","Max displacement","Max speed","Max energy"],0,"Interference & Standing Waves"],
["Gauss's law relates flux to:",["Enclosed charge","Mass","Current","Resistance"],0,"Gauss's Law & Electric Potential"],
["Electric potential of a point charge falls as:",["1/r","1/r²","r","constant"],0,"Gauss's Law & Electric Potential"],
["Inside a conductor in electrostatic equilibrium, the field is:",["Zero","Maximum","Infinite","Uniform non-zero"],0,"Gauss's Law & Electric Potential"],
["Inductive reactance increases with:",["Frequency","Resistance only","Capacitance","Nothing"],0,"AC Circuits"],
["RMS value of a peak V₀ sinusoid:",["V₀/√2","V₀√2","V₀/2","2V₀"],0,"AC Circuits"],
["Radio waves differ from X-rays in:",["Frequency","Speed in vacuum","Being transverse","Being waves"],0,"Electromagnetic Waves"],
["EM waves in vacuum travel at:",["3×10⁸ m/s","3×10⁶ m/s","340 m/s","Variable"],0,"Electromagnetic Waves"],
["Bohr's atom emits light when an electron:",["Drops to a lower level","Rises a level","Stays","Leaves the atom"],0,"Atomic Models & X-rays"],
["X-rays are produced when:",["Fast electrons hit a target","Light bends","Sound reflects","Water boils"],0,"Atomic Models & X-rays"],
["Energy released in fission comes from:",["Mass defect","Chemical bonds","Gravity","Friction"],0,"Nuclear Energy & Particle Physics"],
["Quarks make up:",["Protons and neutrons","Photons","Electrons","Neutrinos"],0,"Nuclear Energy & Particle Physics"],
["A diode mainly allows current:",["In one direction","Both ways","Never","Only AC"],0,"Semiconductors & Electronics"],
["Doping silicon with phosphorus gives:",["n-type","p-type","Insulator","Metal"],0,"Semiconductors & Electronics"],
["Satellite orbital period increases when its radius:",["Increases","Decreases","Stays","Zero"],0,"Orbits & Gravitational Fields"],
["Kepler's 3rd law links period to:",["Orbit radius","Mass of satellite","Colour","Charge"],0,"Orbits & Gravitational Fields"],
["Doubling speed makes kinetic energy:",["4×","2×","Half","Same"],0,"Work, Energy & Power"],
["Free fall ignoring air gives acceleration:",["9.8 m/s² down","0","19.6 m/s²","Increasing"],0,"Kinematics"],
["Action and reaction forces act on:",["Different bodies","Same body","Neither","Only friction"],0,"Newton's Laws & Friction"],
["Heat flows from:",["Hot to cold","Cold to hot","Equal temps","Never"],0,"Heat & Temperature"],
["Pitch of sound depends on:",["Frequency","Amplitude","Medium colour","Loudness only"],0,"Sound & Doppler Effect"],
["Convex lens is:",["Converging","Diverging","Opaque","Flat"],0,"Reflection, Refraction & Lenses"],
["Series resistors share the same:",["Current","Voltage","Power","Resistance"],0,"Current Electricity"],
["Magnetic force on a charge moving parallel to the field:",["Zero","Maximum","Infinite","Negative"],0,"Magnetism & Induction"],
["Photoelectric effect supports:",["Particle nature of light","Wave nature only","Sound waves","Gravity"],0,"Quantum Physics"],
["Moving clocks run:",["Slow","Fast","Same","Backwards"],0,"Special Relativity"],
["Pendulum period is independent of:",["Mass","Length","Gravity","Both length and g"],0,"Simple Harmonic Motion"]);
DICT.push(...`Amplitude modulation|Varying a carrier wave's amplitude to carry a signal
Angular momentum|Rotational analogue of momentum, Iω
Antimatter|Particles with opposite charge to ordinary matter
Armature|Rotating coil in a motor or generator
Black body|Ideal object that absorbs all incident radiation
Bernoulli's principle|Pressure drops as fluid speed rises
Calorimeter|Device measuring heat exchange
Center of mass|Point where mass is considered to act
Coefficient of friction|Ratio of friction force to normal force
Critical angle|Smallest angle giving total internal reflection
Damping|Loss of oscillation energy over time
Dielectric|Insulating material between capacitor plates
Diode|Component allowing current one way
Displacement current|Maxwell term linking changing electric fields to magnetism
Elastic collision|Collision conserving kinetic energy
Electromagnetic spectrum|Range of EM waves from radio to gamma
Electron volt|Energy gained by one electron through 1 V
Fission|Splitting of a heavy nucleus
Fusion|Joining of light nuclei
Gamma ray|High-energy photon from nuclei
Gravitational potential|Potential energy per unit mass in a gravitational field
Inductance|Opposition to current change in a coil (henry)
Laminar flow|Smooth, orderly fluid flow
Lenz's law|Induced current opposes the change that causes it
Moment of inertia|Resistance to rotational acceleration
Neutrino|Nearly massless neutral lepton
Normal force|Support force perpendicular to a surface
Photoelectric effect|Emission of electrons from light hitting metal
Polarisation|Restriction of wave oscillation to one plane
Projectile|Object moving under gravity alone
Radioactivity|Spontaneous nuclear decay
Reactance|AC opposition from inductors or capacitors
Semiconductor|Material with conductivity between metal and insulator
Superposition|Waves add where they overlap
Thermal equilibrium|No net heat flow between bodies
Transverse wave|Oscillation perpendicular to travel
Uncertainty principle|Limit on knowing position and momentum together
Viscosity|Fluid's resistance to flow
Wave-particle duality|Matter and light show both wave and particle behaviour
Weber|SI unit of magnetic flux`.split('\n').map(l=>l.split('|')));
const ADD={"Kinematics":[["Average velocity","v̄ = (u + v)/2","vav","u,v","(u+v)/2"]],"Work, Energy & Power":[["Efficiency","η = useful/total × 100","eta","out,inp","out/inp*100"]],"Momentum & Collisions":[["Elastic collision (v₁ after)","v₁' = ((m₁−m₂)u₁ + 2m₂u₂)/(m₁+m₂)","v1p","m1,m2,u1,u2","((m1-m2)*u1+2*m2*u2)/(m1+m2)"]],"Circular Motion":[["Force from ω","F = mω²r","F","m,w,r","m*w*w*r"]],"Heat & Temperature":[["Mixing final temperature","T = (m₁c₁T₁+m₂c₂T₂)/(m₁c₁+m₂c₂)","T","m1,c1,T1,m2,c2,T2","(m1*c1*T1+m2*c2*T2)/(m1*c1+m2*c2)"]],"Current Electricity":[["Current with internal resistance","I = ε/(R + r)","I","emf,R,r","emf/(R+r)"]],"Electrostatics":[["Capacitors in series","1/C = 1/C₁ + 1/C₂","Cap","C1,C2","1/(1/C1+1/C2)"]],"Reflection, Refraction & Lenses":[["Magnifier (angular)","M = 1 + 25/f","M","f","1+25/f"]],"Quantum Physics":[["Stopping potential","eVs = hf − φ","Vs","f,phi","(C.h*f-phi)/C.e"]],"Atomic & Nuclear Physics":[["Decay constant from half-life","λ = ln2/t½","lam","t","Math.LN2/t"]]};
Object.entries(ADD).forEach(([k,v])=>TOPICS.find(t=>t[1]==k)[3].push(...v));
