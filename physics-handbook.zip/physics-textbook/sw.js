const F=['index.html','extra.css','data.js','data2.js','extras.js','data3.js','data4.js','data5.js','features2.js','features.js','app.js','icon.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open('ph5').then(c=>c.addAll(F))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
